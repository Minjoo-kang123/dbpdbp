package model;

public class Member {
	private int memberID;
	private int pw; //�ϴ� id,pw int�� �ص����� string���� �ٲ� ����.
	private String name;
	private int memberPoint;
	private int sellerPoint;
	
	//grade bday gender point ���߿�
	
	
	public Member() {
		super();
	}
	
	public Member(int memberID, int pw, String name, int memberPoint, int sellerPoint) {
		super();
		this.memberID = memberID;
		this.pw = pw;
		this.name = name;
		this.memberPoint = memberPoint;
		this.sellerPoint = sellerPoint;
	}

	public int getMemberID() {
		return memberID;
	}

	public void setMemberID(int memberID) {
		this.memberID = memberID;
	}

	public int getPw() {
		return pw;
	}

	public void setPw(int pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMemberPoint() {
		return memberPoint;
	}

	public void setMemberPoint(int memberPoint) {
		this.memberPoint = memberPoint;
	}

	public int getSellerPoint() {
		return sellerPoint;
	}

	public void setSellerPoint(int sellerPoint) {
		this.sellerPoint = sellerPoint;
	}
	
	
}
