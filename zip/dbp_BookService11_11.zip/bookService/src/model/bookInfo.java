package model;

public class bookInfo {

}
