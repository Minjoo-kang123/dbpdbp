package model;

public class rentalBook {
	
	private int bookID;
	private int sellerID;
	private int bookInfoID;
	private String image;
	private String explain;
	
	public rentalBook(int bookID, int sellerID, int bookInfoID, String image, String explain) {
		super();
		this.bookID = bookID;
		this.sellerID = sellerID;
		this.bookInfoID = bookInfoID;
		this.image = image;
		this.explain = explain;
	}
	
	public rentalBook() {
		super();
	}
	public int getBookID() {
		return bookID;
	}
	public void setBookID(int bookID) {
		this.bookID = bookID;
	}
	public int getSellerID() {
		return sellerID;
	}
	public void setSellerID(int sellerID) {
		this.sellerID = sellerID;
	}
	public int getBookInfoID() {
		return bookInfoID;
	}
	public void setBookInfoID(int bookInfoID) {
		this.bookInfoID = bookInfoID;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getExplain() {
		return explain;
	}
	public void setExplain(String explain) {
		this.explain = explain;
	}
	
	
}
